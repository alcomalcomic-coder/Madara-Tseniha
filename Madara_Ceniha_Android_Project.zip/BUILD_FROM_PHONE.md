# Если принципиально собирать APK тоже без компьютера

Можно использовать бесплатную облачную сборку GitHub Actions (в пределах доступных лимитов GitHub).

1. Создай приватный репозиторий на github.com.
2. Загрузи туда один файл `Madara_Ceniha_Android_Project.zip` (этот же архив с исходниками). Он должен лежать в корне репозитория.
3. В репозитории нажми **Add file → Create new file**. Назови его `.github/workflows/apk.yml` и вставь код ниже.
4. Сохрани файл через Commit changes.
5. Открой Actions → **Build Madara APK from ZIP** → Run workflow. Когда сборка пройдёт, скачай артефакт `Madara-Ceniha-APK` из этого запуска и установи `app-debug.apk`.

```yaml
name: Build Madara APK from ZIP
on:
  workflow_dispatch:
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - name: Install Android SDK
        run: sdkmanager "platforms;android-35" "build-tools;35.0.0"
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - name: Extract Android project
        run: mkdir -p source && unzip -q Madara_Ceniha_Android_Project.zip -d source
      - name: Compile APK
        working-directory: source
        run: gradle :app:assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: Madara-Ceniha-APK
          path: source/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```

Важное замечание: сборка GitHub Actions использует временный **debug-ключ подписи**, поэтому APK из двух разных запусков может не обновлять друг друга поверх. Перед переустановкой сохрани резервную копию JSON в настройках приложения. Для стабильных обновлений впоследствии следует настроить собственный постоянный release-ключ (и хранить его как секрет GitHub, а не выкладывать в репозиторий).
