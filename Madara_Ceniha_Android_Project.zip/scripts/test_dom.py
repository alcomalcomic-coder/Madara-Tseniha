from playwright.sync_api import sync_playwright
from pathlib import Path
core=Path(__file__).parents[1]/'app/src/main/assets/core.js'
fixture='''<!DOCTYPE html><html lang="ru"><body>
<section>
<a href="/ru/catalog/local-2026?page=11" class="whole">-33% Leo'dor Сухарики в ассортименте 80г 7.99 лей 11.99 Истекает через 2 дн.</a>
<div class="product-card"><a href="/ru/catalog/local-2026?page=2"><img src="https://croco.md/img/test.jpg"></a><strong>-50%</strong><div>Yaw Max Сухарики 85г</div><div>7.99 лей</div><s>15.99</s></div>
<div class="card"><a href="/ru/catalog/linella-a">Roshen Lovita Печенье 135г</a><div class="pricing"><b>17.99 lei</b><del>18.99</del><em>-5%</em></div></div>
</section></body></html>'''
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page();page.set_content('<html><body><script src="file://'+str(core)+'"></script></body></html>');page.add_script_tag(path=str(core));
 v=page.evaluate("""html => {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  return {offers: window.MadaraCore.extractOffers(doc,'Local',6), diagnostics:window.MadaraCore.inspectMarkup(doc)};
 }""",fixture)
 print(v)
 assert len(v['offers'])==3,v
 assert v['offers'][0]['price']==7.99
 assert v['offers'][1]['old_price']==15.99
 assert v['offers'][2]['price']==17.99
 b.close()
