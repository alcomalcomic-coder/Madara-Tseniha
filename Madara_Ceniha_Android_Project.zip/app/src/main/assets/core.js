/* Portable parsing and careful cross-store matching; no dependencies. */
(function(root){
'use strict';
const categoryLabels={1:'Мясо и птица',2:'Овощи и фрукты',3:'Хлеб и выпечка',4:'Бакалея',5:'Напитки',6:'Соусы и консервы',7:'Сладости и снеки',8:'Для детей',9:'Красота и гигиена',10:'Для дома',11:'Для животных',12:'Для дома',13:'Другое',14:'Для дома'};
const cats=['Овощи и фрукты','Мясо и птица','Рыба и морепродукты','Молочные продукты','Яйца','Хлеб и выпечка','Бакалея','Сладости и снеки','Напитки','Заморозка','Соусы и консервы','Для дома','Красота и гигиена','Для детей','Для животных','Другое'];
function norm(s){return String(s||'').toLowerCase().replaceAll('ё','е').replace(/komo|комо/gi,'komo').replace(/edam|эдам/gi,'edam').replace(/rudь|рудь/gi,'rud').replace(/bucovina|буковина/gi,'bucovina').replace(/\blay'?s\b|лейс/gi,'lays').replace(/[^\p{L}\p{N}%]+/gu,' ').replace(/\s+/g,' ').trim()}
function classify(name,cat){
 const s=norm(name);
 if(/(?:сыр|брынза|творог|сметана|кефир|йогурт|молоко|сливки|edam|komo)/.test(s))return 'Молочные продукты';
 if(/(?:лосос|форель|рыб|тунец|шпрот|мидии|креветк)/.test(s))return 'Рыба и морепродукты';
 if(/(?:яйц)/.test(s))return 'Яйца';
 if(/(?:чипсы|печень|мороженое|шоколад|сухарики|конфет|крекер|вафли|попкорн|батончик)/.test(s))return 'Сладости и снеки';
 if(/(?:кофе|чай|сок|напиток|вод[ауы]|нектар|лимонад)/.test(s))return 'Напитки';
 if(/(?:хлеб|батон|булочк|лаваш|круассан)/.test(s))return 'Хлеб и выпечка';
 if(/(?:гель для душа|шампун|мыло|дезодорант|паста зуб|зубная паста)/.test(s))return 'Красота и гигиена';
 if(/(?:пельмени|вареники|замороженн)/.test(s))return 'Заморозка';
 if(/(?:огурц|помидор|банан|яблок|груш|лимон|персик|арбуз)/.test(s))return 'Овощи и фрукты';
 return cat||'Другое';
}
function offerText(raw,store,category,url,image){
 let s=String(raw||'').replace(/\s+/g,' ').trim();
 const expires=s.match(/\s+(Истекает\s+.*|Expiră\s+.*)$/i);
 if(expires)s=s.slice(0,expires.index).trim();
 // Some product tiles show "лей", others display "lei", "MDL" or "L".
 // Identify money tokens; never interpret a bare weight as a price.
 const marked=/(\d{1,5}(?:[\s\u00a0\u202f]\d{3})*[,.]\d{2})\s*(?:лей|lei|mdl|L\b)/gi;
 const values=[...s.matchAll(marked)];
 let cut=-1,price=null,old=null;
 function money(v){return Number(String(v||'').replace(/[\s\u00a0\u202f]/g,'').replace(',','.'))}
 if(values.length){
  const first=values[0];cut=first.index;price=money(first[1]);
  // An old price is commonly bare (not followed by a second currency label).
  const tail=s.slice(first.index+first[0].length);
  const next=tail.match(/^\s*(\d{1,5}(?:[\s\u00a0\u202f]\d{3})*[,.]\d{2})(?!\s*(?:г|мл))\b/);
  if(next)old=money(next[1]);
  else if(values.length>1)old=money(values[1][1]);
 }else{
  // Conservative fallback for tiles where currency symbols live outside the link.
  // A percentage AND two decimal numbers are mandatory to avoid inventing offers.
  const pct=s.match(/(?:^|\s)[−-](\d{1,2})\s*%/);
  if(!pct)return null;
  const decimals=[...s.matchAll(/\b\d{1,5}[,.]\d{2}\b/g)];
  if(decimals.length<2)return null;
  const a=decimals[decimals.length-2],b=decimals[decimals.length-1];
  cut=a.index;price=money(a[0]);old=money(b[0]);
 }
 let name=s.slice(0,cut).trim();
 // A promotion percentage can occur before OR after the title.
 const pct=name.match(/[−-]\s*(\d{1,2})\s*%/);
 const discount=pct?Number(pct[1]):null;
 if(pct)name=name.replace(pct[0],' ').replace(/\s+/g,' ').trim();
 if(old!==null && Number.isFinite(old) && price>old){const t=price;price=old;old=t}
 if(!Number.isFinite(price)||price<=0||price>999999||name.length<3||name.length>180)return null;
 if(old!==null && (!Number.isFinite(old)||old<=price||old>999999))old=null;
 // Reject large blocks and gallery prose even if they happen to contain a price.
 if(/(?:Категории|Сбросить|Download on the App Store|Политика конфиденциальности)/i.test(name))return null;
 return {store,name,price,old_price:old,discount_pct:old&&old>price?Math.round((1-price/old)*100):discount,
 category:classify(name,categoryLabels[category]),currency:'MDL',price_unit:'упак',price_origin:'web',image_url:image||'',source_url:url||'',expiry_text:expires?expires[1]:'',last_seen:new Date().toISOString(),favorite:0,note:'',barcode:''};
}
function productLink(a){
 try{
  const raw=a.getAttribute('href');if(!raw)return null;
  const url=new URL(raw,'https://croco.md');
  if(!['croco.md','www.croco.md'].includes(url.hostname))return null;
  if(!/\/(?:catalog|produs|product|produse)\//i.test(url.pathname))return null;
  return url.href;
 }catch{return null}
}
function imageFor(el){
 for(const im of el.querySelectorAll('img,source')){
  const raw=im.getAttribute('data-original')||im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||im.getAttribute('srcset')||'';
  if(!raw||raw.startsWith('data:')||raw.startsWith('blob:'))continue;
  try{
   const u=new URL(raw.split(',')[0].trim().split(' ')[0],'https://croco.md');
   if(u.protocol!=='https:'||/placeholder|loading|pixel|spacer|logo/i.test(u.pathname))continue;
   return u.href;
  }catch{}
 }
 return '';
}
function extractOffers(doc,store,category){
 const output=[],seen=new Set();
 const anchors=[...doc.querySelectorAll('a[href]')].filter(a=>productLink(a));
 for(const a of anchors){
  const url=productLink(a);
  // Start at the actual link. If it contains only an image/title,
  // climb to the smallest parent tile containing price and name.
  let tile=a;
  for(let level=0;level<5;level++){
   const text=(tile.textContent||'').replace(/\s+/g,' ').trim();
   if(text.length>620)break;
   const withPrice=/(?:\d{1,5}[,.]\d{2}\s*(?:лей|lei|mdl|L\b)|[−-]\s*\d{1,2}\s*%)/i.test(text);
   if(withPrice && text.length>=10){
    const candidate=offerText(text,store,category,url,imageFor(tile));
    if(candidate){
     const key=norm(candidate.name)+'|'+candidate.price;
     if(!seen.has(key)){seen.add(key);output.push(candidate)}
     break;
    }
   }
   const parent=tile.parentElement;
   if(!parent || parent.tagName==='BODY')break;
   const nLinks=[...parent.querySelectorAll('a[href]')].filter(k=>productLink(k)).length;
   if(nLinks>1)break; // Never mix prices between neighbouring products.
   tile=parent;
  }
 }
 // Sites sometimes use a non-clickable wrapper with the product details.
 // Only accept compact tiles carrying a discount and a currency-labelled price.
 if(!output.length){
  const blocks=doc.querySelectorAll('article, [class*="product"], [class*="offer"], [class*="card"], [class*="tile"]');
  for(const tile of blocks){
   const label=(tile.textContent||'').replace(/\s+/g,' ').trim();
   if(label.length<12||label.length>450||!/[−-]\s*\d{1,2}\s*%/.test(label)||!/(?:лей|lei|MDL)\b/i.test(label))continue;
   const links=[...tile.querySelectorAll('a[href]')].map(productLink).filter(Boolean);
   if(links.length>1)continue;
   const offer=offerText(label,store,category,links[0]||'',imageFor(tile));
   if(!offer)continue;
   const key=norm(offer.name)+'|'+offer.price;
   if(!seen.has(key)){seen.add(key);output.push(offer)}
  }
 }
 return output;
}
function inspectMarkup(doc){
 const text=(doc.body?.textContent||'').replace(/\s+/g,' ').trim();
 const title=(doc.title||'').trim().slice(0,95);
 const links=[...doc.querySelectorAll('a[href]')].filter(a=>productLink(a)).length;
 const priceWords=(text.match(/(?:лей|lei|MDL)/gi)||[]).length;
 const percent=(text.match(/[−-]\s*\d{1,2}\s*%/g)||[]).length;
 return {title,characters:text.length,links,priceWords,percent,sample:text.slice(0,170)};
}

const ignored=new Set('весовой вес порционный упаковка упак уп в ассортименте продукт сыр молочный молочная свежее свежий из со для на и с 1 шт кг г мл л'.split(' '));
function tokens(p){return [...new Set(norm(p.name).split(' ').filter(x=>x.length>=3&&!ignored.has(x)&&!/^(?:\d+|\d+г|\d+мл)$/.test(x)))];}
function fat(name){const m=norm(name).match(/(\d{1,2}(?:[.,]\d)?)\s*%/);return m?Number(m[1].replace(',','.')):null}
function flavor(name){const n=norm(name);const groups=[['клубнич','землянич'],['вишн'],['яблок'],['лимон'],['персик'],['шоколад','какао'],['кокос'],['миндал'],['сливочн'],['салями'],['сырн'],['грибн'],['ванил'],['малин'],['апельсин'],['лук'],['сметан'],['чеснок']];return groups.findIndex(g=>g.some(x=>n.includes(x)));}
function amount(p){
 if(p.price_unit==='кг')return {kind:'kg',unitPrice:p.price};
 if(p.price_unit==='л')return {kind:'l',unitPrice:p.price};
 const s=norm(p.name);
 const found=[...s.matchAll(/(\d+(?:[.,]\d+)?)\s*(кг|гр|г|литр|л|мл)(?=$|\s|[,.;)\]])/g)];
 if(!found.length)return null;
 const m=found[found.length-1],q=Number(m[1].replace(',','.'));if(!(q>0))return null;
 const kg=['г','гр','кг'].includes(m[2]);const v=q*(m[2]==='кг'||m[2]==='литр'||m[2]==='л'?1:0.001);
 if(!(v>0))return null;
 return {kind:kg?'kg':'l',unitPrice:p.price/v};
}
function pairKey(a,b){return [Number(a),Number(b)].sort((x,y)=>x-y).join(':')}
function similarity(a,b){
 if(a.id===b.id||a.store===b.store)return {score:0,reason:'same-store'};
 if(a.barcode && b.barcode && a.barcode===b.barcode)return {score:1,reason:'barcode',sure:true};
 const ca=a.user_category||a.auto_category||a.category;
 const cb=b.user_category||b.auto_category||b.category;
 if(ca!==cb && ca!=='Другое' && cb!=='Другое')return {score:0,reason:'category'};
 const f1=fat(a.name),f2=fat(b.name);
 if(f1!==null&&f2!==null&&Math.abs(f1-f2)>0.01)return {score:0,reason:'fat'};
 const v1=flavor(a.name),v2=flavor(b.name);
 if(v1>=0&&v2>=0&&v1!==v2)return {score:0,reason:'flavor'};
 const ta=tokens(a),tb=tokens(b);
 const match=ta.filter(t=>tb.some(u=>t===u || (t.length>5&&u.length>5&&(t.startsWith(u)||u.startsWith(t)))));
 const score=match.length/Math.max(ta.length,tb.length,1);
 const quant1=amount(a),quant2=amount(b);
 // We do not auto-merge only generic product names; verification is key.
 const brands=new Set(['komo','rud','bucovina','tess','lays','lays','roshen','flint','rogob','vici','arla','sen','soy','old','spice','bruschet','eco','line','delice','helcom']);
 const brandMatch=match.some(t=>brands.has(t));
 const sure=match.length>=2 && score>=0.9 && (brandMatch||match.length>=4) && f1===f2 && (v1===v2||v1<0||v2<0) && Boolean(quant1&&quant2&&quant1.kind===quant2.kind);
 return {score,sure,reason:match.length+' common tokens'};
}
function comparePrice(a,b,rate){
 const x=amount(a),y=amount(b);if(!x||!y||x.kind!==y.kind)return null;
 if(a.currency!==b.currency && !(rate>0))return null;
 const ax=x.unitPrice*(a.currency==='MDL'?rate:1),by=y.unitPrice*(b.currency==='MDL'?rate:1);
 return {a:ax,b:by,unit:x.kind==='kg'?'кг':'л'};
}
root.MadaraCore={cats,categoryLabels,classify,norm,offerText,extractOffers,inspectMarkup,amount,pairKey,tokens,fat,flavor,similarity,comparePrice};
})(typeof window!=='undefined'?window:globalThis);
