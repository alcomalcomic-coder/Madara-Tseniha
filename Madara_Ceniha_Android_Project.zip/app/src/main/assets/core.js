/* Portable parsing and careful cross-store matching; no dependencies. */
(function(root){
'use strict';
const categoryLabels={1:'Мясо и птица',2:'Овощи и фрукты',3:'Хлеб и выпечка',4:'Бакалея',5:'Напитки',6:'Соусы и консервы',7:'Сладости и снеки',8:'Для детей',9:'Красота и гигиена',10:'Для дома',11:'Для животных',12:'Для дома',13:'Другое',14:'Для дома'};
const cats=['Овощи и фрукты','Мясо и птица','Рыба и морепродукты','Молочные продукты','Яйца','Хлеб и выпечка','Бакалея','Сладости и снеки','Напитки','Заморозка','Соусы и консервы','Для дома','Красота и гигиена','Для детей','Для животных','Другое'];
function norm(s){return String(s||'').toLowerCase().replaceAll('ё','е').replace(/komo|комо/gi,'komo').replace(/edam|эдам/gi,'edam').replace(/rudь|рудь/gi,'rud').replace(/bucovina|буковина/gi,'bucovina').replace(/\blay'?s\b|лейс/gi,'lays').replace(/[^\p{L}\p{N}%]+/gu,' ').replace(/\s+/g,' ').trim()}
function classify(name,cat){
 const s=norm(name);
 if(/(?:сыр|брынза|творог|сметана|кефир|йогурт|молоко|сливки|edam|komo)/.test(s))return 'Молочные продукты';
 if(/(?:лосос|форель|рыб|тунец|шпрот|мидии|креветк)/.test(s))return 'Рыба и морепродукты';
 if(/(?:яйц)/.test(s))return 'Яйца';
 if(/(?:чипсы|печень|мороженое|шоколад|сухарики|конфет|крекер|вафли|попкорн|батончик)/.test(s))return 'Сладости и снеки';
 if(/(?:кофе|чай|сок|напиток|вод[ауы]|нектар|лимонад)/.test(s))return 'Напитки';
 if(/(?:хлеб|батон|булочк|лаваш|круассан)/.test(s))return 'Хлеб и выпечка';
 if(/(?:гель для душа|шампун|мыло|дезодорант|паста зуб|зубная паста)/.test(s))return 'Красота и гигиена';
 if(/(?:пельмени|вареники|замороженн)/.test(s))return 'Заморозка';
 if(/(?:огурц|помидор|банан|яблок|груш|лимон|персик|арбуз)/.test(s))return 'Овощи и фрукты';
 return cat||'Другое';
}
function offerText(raw,store,category,url,image){
 let s=String(raw||'').replace(/\s+/g,' ').trim();
 const expires=s.match(/\s+(Истекает\s+.*|Expiră\s+.*)$/i);
 if(expires)s=s.slice(0,expires.index).trim();
 const pattern=/(\d[\d\s\u00a0\u202f]*[,.]\d{2})\s*(?:лей|lei)(?:\s+(\d[\d\s\u00a0\u202f]*[,.]\d{2}))?/gi;
 let m,last;while((m=pattern.exec(s))!==null)last=m;
 if(!last)return null;
 let name=s.slice(0,last.index).trim();
 const pct=name.match(/^-(\d{1,2})\s*%\s*/);const discount=pct?+pct[1]:null;
 if(pct)name=name.slice(pct[0].length).trim();
 function money(v){return Number(String(v||'').replace(/[\s\u00a0\u202f]/g,'').replace(',','.'))}
 const price=money(last[1]);let old=last[2]?money(last[2]):null;
 if(!Number.isFinite(price)||price<=0||price>999999||name.length<3||name.length>180)return null;
 if(old!==null && (old<price||old>999999))old=null;
 return {store,name,price,old_price:old,discount_pct:old&&old>price?Math.round((1-price/old)*100):discount,
 category:classify(name,categoryLabels[category]),currency:'MDL',price_unit:'упак',price_origin:'web',image_url:image||'',source_url:url||'',expiry_text:expires?expires[1]:'',last_seen:new Date().toISOString(),favorite:0,note:'',barcode:''};
}
function extractOffers(doc,store,category){
 const output=[],seen=new Set();
 for(const a of doc.querySelectorAll('a[href]')){
  const label=(a.textContent||'').replace(/\s+/g,' ').trim();
  if(!/\b(?:лей|lei)\b/i.test(label))continue;
  let url;try{url=new URL(a.getAttribute('href'),'https://croco.md')}catch{continue}
  if(!['croco.md','www.croco.md'].includes(url.hostname)||!url.pathname.match(/\/(?:catalog|produs|product|produse)\//))continue;
  let img='';
  for(const im of a.querySelectorAll('img,source')){
   const raw=im.getAttribute('data-original')||im.getAttribute('data-src')||im.getAttribute('data-lazy-src')||im.getAttribute('src')||im.getAttribute('srcset')||'';
   if(!raw||raw.startsWith('data:')||raw.startsWith('blob:'))continue;
   try{const u=new URL(raw.split(',')[0].trim().split(' ')[0],'https://croco.md');if(u.protocol!=='https:'||/placeholder|loading|pixel|spacer|logo/i.test(u.pathname))continue;img=u.href;break;}catch{}
  }
  const offer=offerText(label,store,category,url.href,img);
  if(!offer)continue;
  const key=norm(offer.name)+'|'+offer.price;if(seen.has(key))continue;seen.add(key);output.push(offer);
 }
 return output;
}
const ignored=new Set('весовой вес порционный упаковка упак уп в ассортименте продукт сыр молочный молочная свежее свежий из со для на и с 1 шт кг г мл л'.split(' '));
function tokens(p){return [...new Set(norm(p.name).split(' ').filter(x=>x.length>=3&&!ignored.has(x)&&!/^(?:\d+|\d+г|\d+мл)$/.test(x)))];}
function fat(name){const m=norm(name).match(/(\d{1,2}(?:[.,]\d)?)\s*%/);return m?Number(m[1].replace(',','.')):null}
function flavor(name){const n=norm(name);const groups=[['клубнич','землянич'],['вишн'],['яблок'],['лимон'],['персик'],['шоколад','какао'],['кокос'],['миндал'],['сливочн'],['салями'],['сырн'],['грибн'],['ванил'],['малин'],['апельсин'],['лук'],['сметан'],['чеснок']];return groups.findIndex(g=>g.some(x=>n.includes(x)));}
function amount(p){
 if(p.price_unit==='кг')return {kind:'kg',unitPrice:p.price};
 if(p.price_unit==='л')return {kind:'l',unitPrice:p.price};
 const s=norm(p.name);
 const found=[...s.matchAll(/(\d+(?:[.,]\d+)?)\s*(кг|гр|г|литр|л|мл)(?=$|\s|[,.;)\]])/g)];
 if(!found.length)return null;
 const m=found[found.length-1],q=Number(m[1].replace(',','.'));if(!(q>0))return null;
 const kg=['г','гр','кг'].includes(m[2]);const v=q*(m[2]==='кг'||m[2]==='литр'||m[2]==='л'?1:0.001);
 if(!(v>0))return null;
 return {kind:kg?'kg':'l',unitPrice:p.price/v};
}
function pairKey(a,b){return [Number(a),Number(b)].sort((x,y)=>x-y).join(':')}
function similarity(a,b){
 if(a.id===b.id||a.store===b.store)return {score:0,reason:'same-store'};
 if(a.barcode && b.barcode && a.barcode===b.barcode)return {score:1,reason:'barcode',sure:true};
 const ca=a.user_category||a.auto_category||a.category;
 const cb=b.user_category||b.auto_category||b.category;
 if(ca!==cb && ca!=='Другое' && cb!=='Другое')return {score:0,reason:'category'};
 const f1=fat(a.name),f2=fat(b.name);
 if(f1!==null&&f2!==null&&Math.abs(f1-f2)>0.01)return {score:0,reason:'fat'};
 const v1=flavor(a.name),v2=flavor(b.name);
 if(v1>=0&&v2>=0&&v1!==v2)return {score:0,reason:'flavor'};
 const ta=tokens(a),tb=tokens(b);
 const match=ta.filter(t=>tb.some(u=>t===u || (t.length>5&&u.length>5&&(t.startsWith(u)||u.startsWith(t)))));
 const score=match.length/Math.max(ta.length,tb.length,1);
 const quant1=amount(a),quant2=amount(b);
 // We do not auto-merge only generic product names; verification is key.
 const brands=new Set(['komo','rud','bucovina','tess','lays','lays','roshen','flint','rogob','vici','arla','sen','soy','old','spice','bruschet','eco','line','delice','helcom']);
 const brandMatch=match.some(t=>brands.has(t));
 const sure=match.length>=2 && score>=0.9 && (brandMatch||match.length>=4) && f1===f2 && (v1===v2||v1<0||v2<0) && Boolean(quant1&&quant2&&quant1.kind===quant2.kind);
 return {score,sure,reason:match.length+' common tokens'};
}
function comparePrice(a,b,rate){
 const x=amount(a),y=amount(b);if(!x||!y||x.kind!==y.kind)return null;
 if(a.currency!==b.currency && !(rate>0))return null;
 const ax=x.unitPrice*(a.currency==='MDL'?rate:1),by=y.unitPrice*(b.currency==='MDL'?rate:1);
 return {a:ax,b:by,unit:x.kind==='kg'?'кг':'л'};
}
root.MadaraCore={cats,categoryLabels,classify,norm,offerText,extractOffers,amount,pairKey,tokens,fat,flavor,similarity,comparePrice};
})(typeof window!=='undefined'?window:globalThis);
