'use strict';
const C=window.MadaraCore;
const $=id=>document.getElementById(id);
const deepCopy=x=>JSON.parse(JSON.stringify(x));
const native=window.MadaraNative||null;
let db;
try{const saved=native?native.loadData():localStorage.getItem('madara_data_v1');db=saved?JSON.parse(saved):deepCopy(window.MADARA_SEED)}catch{db=deepCopy(window.MADARA_SEED)}
if(!db || !Array.isArray(db.products)||!Array.isArray(db.receipts))db=deepCopy(window.MADARA_SEED);
db.cart=db.cart||[];db.matches=db.matches||{};db.nextId=Math.max(db.nextId||0,...db.products.map(p=>p.id+1));
const state={view:'catalog',store:'all',query:'',cat:'all',sort:'discount',fav:false,current:false,limit:50,editing:null,editingCategory:null,compareId:null,syncAbort:false,syncBusy:false};
function save(){const str=JSON.stringify(db);try{const success=native?native.saveData(str):(localStorage.setItem('madara_data_v1',str),true);if(!success)notify('Не удалось сохранить данные, сделайте резервную копию.')}catch(e){notify('Ошибка хранилища: '+e.message)}}
function notify(s){let x=$('toast');x.textContent=s;x.classList.remove('hidden');clearTimeout(notify.timer);notify.timer=setTimeout(()=>x.classList.add('hidden'),3800)}
function fmt(v,currency){return new Intl.NumberFormat('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(v)||0)+' '+(currency==='MDL'?'MDL':'₽')}
function dateLabel(s){if(!s)return 'нет данных';const d=new Date(s);return Number.isNaN(d.getTime())?'неизвестно':d.toLocaleDateString('ru-RU')}
function recent(p){if(p.store==='Шериф')return false;return Boolean(p.last_seen && Date.now()-new Date(p.last_seen).getTime()<4*864e5)}
function changedView(view){state.view=view;for(const v of ['catalog','sheriff','cart','settings'])$(v+'View').classList.toggle('hidden',v!==view);document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));if(view==='catalog')drawCatalog();else if(view==='sheriff')drawReceipts();else if(view==='cart')drawCart();else drawStats();window.scrollTo(0,0)}
function emoji(p){const k=p.user_category||p.auto_category||p.category;return {'Овощи и фрукты':'🍒','Мясо и птица':'🍗','Рыба и морепродукты':'🐟','Молочные продукты':'🧀','Яйца':'🥚','Хлеб и выпечка':'🥐','Бакалея':'🌾','Сладости и снеки':'🍪','Напитки':'🧃','Заморозка':'🧊','Соусы и консервы':'🥫','Для дома':'🧽','Красота и гигиена':'🧴','Для детей':'🍼','Для животных':'🐾'}[k]||'🛒'}
function node(tag,cls,txt){let e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;return e}
function btn(s,cls,fn){let b=node('button',cls,s);b.type='button';b.onclick=fn;return b}
function discount(p){if(p.old_price>p.price)return Math.round((1-p.price/p.old_price)*100);return Math.max(0,Number(p.discount_pct)||0)}
function currentProducts(){const search=C.norm(state.query);let list=db.products.filter(p=>(state.store==='all'||p.store===state.store)&&(!state.fav||p.favorite)&&(!state.current||p.store==='Шериф'||recent(p))&&(state.cat==='all'||(p.user_category||p.auto_category||p.category)===state.cat)&&(!search||C.norm(p.name).includes(search)));
list.sort((a,b)=>state.sort==='price'?a.price-b.price:state.sort==='name'?a.name.localeCompare(b.name,'ru'):state.sort==='new'?new Date(b.last_seen||0)-new Date(a.last_seen||0):discount(b)-discount(a)||a.name.localeCompare(b.name,'ru'));return list}
function drawCatalog(){const list=currentProducts();$('total').textContent=list.length+' товаров';const parent=$('catalogList');parent.replaceChildren();const fragment=document.createDocumentFragment();
for(const p of list.slice(0,state.limit)){
 const card=node('article','product');const pic=node('div','picture',emoji(p));
 const src=p.image_data||p.image_url;if(src && (/^data:image\/(jpeg|png|webp);base64,/i.test(src)||/^https:\/\//i.test(src))){const im=document.createElement('img');im.loading='lazy';im.alt='';im.src=src;im.onerror=()=>im.remove();pic.append(im)}
 card.append(pic);if(discount(p)>0){const off=node('div','off','−'+discount(p)+'%');card.append(off)}
 const body=node('div','item-body');body.append(node('div','item-name',p.name));body.append(node('span','item-store',p.store+' · '+(p.user_category||p.auto_category||p.category||'Другое')));
 const line=node('div','item-price');line.append(node('span','price',fmt(p.price,p.currency)));if(p.old_price>p.price)line.append(node('span','struck',fmt(p.old_price,p.currency)));body.append(line);
 if(p.old_price>p.price)body.append(node('div','saved','Выгода '+fmt(p.old_price-p.price,p.currency)));
 const by=C.amount(p);if(by)body.append(node('div','fresh','≈ '+fmt(by.unitPrice,p.currency)+'/'+(by.kind==='kg'?'кг':'л')));
 body.append(node('span','fresh',p.price_origin==='receipt'?'Историческая цена из чека · дата неизвестна':p.store==='Шериф'?'Добавлено вручную':'Croco · '+dateLabel(p.last_seen)+(recent(p)?'':' · может устареть')));
 const fav=btn(p.favorite?'★':'☆','favorite',()=>{p.favorite=p.favorite?0:1;save();drawCatalog()});fav.setAttribute('aria-label','Избранное');card.append(fav);
 const tools=node('div','product-actions');tools.append(btn('⚔ Сравнить','compare',()=>showCompare(p.id)));tools.append(btn('＋ Список','',()=>{const already=db.cart.find(x=>x.id===p.id);if(!already)db.cart.push({id:p.id,quantity:1,checked:false});save();notify('Товар в списке покупок')}));
 tools.append(btn('Категория','',()=>{state.editingCategory=p.id;$('categoryOverride').value=p.user_category||p.auto_category||p.category||'Другое';$('editCategory').showModal()}));
 if(p.store==='Шериф'&&p.price_origin==='manual')tools.append(btn('✎ Изменить','',()=>editManual(p)));
 if(p.store==='Шериф'){
  const photo=document.createElement('input');photo.type='file';photo.accept='image/*';photo.className='hidden';photo.onchange=async()=>{if(!photo.files?.[0])return;try{p.image_data=await resizePhoto(photo.files[0]);save();drawCatalog();notify('Фото сохранено на телефоне')}catch(e){notify(e.message)}};
  tools.append(btn('📷','',()=>photo.click()),photo)
 }
 body.append(tools);card.append(body);fragment.append(card)
}
parent.append(fragment);if(!list.length)parent.append(node('div','empty','Ничего не найдено. Попробуй другую категорию или добавь товар «Шерифа».'));
$('more').classList.toggle('hidden',list.length<=state.limit)}
async function resizePhoto(file){if(file.size>12*1024*1024)throw Error('Выберите фотографию до 12 МБ');return new Promise((resolve,reject)=>{
 const reader=new FileReader();reader.onerror=()=>reject(Error('Не удалось прочитать фото'));reader.onload=()=>{
 const im=new Image();im.onload=()=>{const canvas=document.createElement('canvas');const r=Math.min(1,420/Math.max(im.width,im.height));canvas.width=Math.max(1,Math.round(im.width*r));canvas.height=Math.max(1,Math.round(im.height*r));canvas.getContext('2d').drawImage(im,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL('image/jpeg',.65))};im.onerror=()=>reject(Error('Файл не является изображением'));im.src=reader.result};reader.readAsDataURL(file)
})}
function editManual(p){changedView('sheriff');state.editing=p.id;$('editId').value=p.id;$('manualName').value=p.name;$('manualPrice').value=p.price;$('manualUnit').value=p.price_unit;$('manualCategory').value=p.user_category||p.auto_category||p.category||'Другое';$('manualBarcode').value=p.barcode||'';$('manualNote').value=p.note||'';$('manualImage').value='';$('manualSave').textContent='Сохранить изменения';$('cancelEdit').classList.remove('hidden');$('deleteManual').classList.remove('hidden');$('manualName').focus()}
function resetManual(){$('manualForm').reset();state.editing=null;$('editId').value='';$('manualCategory').value='Другое';$('manualSave').textContent='＋ Сохранить товар';$('cancelEdit').classList.add('hidden');$('deleteManual').classList.add('hidden')}
async function submitManual(e){e.preventDefault();const name=$('manualName').value.trim(),price=Number($('manualPrice').value);if(name.length<2||name.length>180||!Number.isFinite(price)||price<=0||price>100000){notify('Проверь название и цену');return}
 const before=db.products.find(p=>p.id===state.editing),dup=db.products.find(p=>p.id!==state.editing&&p.store==='Шериф'&&C.norm(p.name)===C.norm(name));if(dup){notify('Этот товар уже есть в базе «Шерифа»');return}
 const input=$('manualImage').files?.[0];let photo='';if(input){try{photo=await resizePhoto(input)}catch(e){notify(e.message);return}}
 const p=before||{id:db.nextId++,store:'Шериф',currency:'PMR',favorite:0,image_url:'',price_origin:'manual',old_price:null,discount_pct:null,source_url:''};Object.assign(p,{name,price,price_unit:$('manualUnit').value,category:$('manualCategory').value,auto_category:$('manualCategory').value,user_category:$('manualCategory').value,barcode:$('manualBarcode').value.trim(),note:$('manualNote').value.trim(),last_seen:new Date().toISOString()});if(photo)p.image_data=photo;
 if(!before)db.products.push(p);save();resetManual();changedView('catalog');state.store='Шериф';document.querySelectorAll('[data-store]').forEach(b=>b.classList.toggle('chosen',b.dataset.store==='Шериф'));notify('Товар сохранён на телефоне')}
function drawReceipts(){const buttons=$('receiptButtons');buttons.replaceChildren();for(const r of db.receipts){buttons.append(btn('№'+r.receipt_id+' · '+fmt(r.receipt_total,r.currency),'',()=>{
 const d=$('receiptDetails');d.replaceChildren();const block=node('div','panel');block.append(node('h3','',`Чек №${r.receipt_id} · ${fmt(r.receipt_total,r.currency)}`));block.append(node('p','muted tiny','Дата покупки не установлена'));for(const i of r.items){const row=node('div','receipt-line');row.append(node('div','',i.line_number+'. '+i.name));row.append(node('div','muted',`${i.quantity} ${i.unit} × ${fmt(i.unit_price,'PMR')} = ${fmt(i.line_total,'PMR')}`));block.append(row)}d.append(block)
 }))}}
function drawCart(){const box=$('cartList');box.replaceChildren();let totalPMR=0,totals={MDL:0,PMR:0},rest=0;
 for(const row of db.cart){const p=db.products.find(x=>x.id===row.id);if(!p)continue;if(!row.checked){totals[p.currency]=(totals[p.currency]||0)+p.price*row.quantity;rest++}
 const wrapper=node('div','cart-item'+(row.checked?' done':''));const line=node('div','row gap');const chk=document.createElement('input');chk.type='checkbox';chk.checked=!!row.checked;chk.onchange=()=>{row.checked=chk.checked;save();drawCart()};line.append(chk);const text=node('div','grow');text.append(node('div','',p.name));text.append(node('span','muted tiny',p.store+' · '+fmt(p.price,p.currency)+' / '+(p.price_unit||'упак')));line.append(text);line.append(btn('✕','mini',()=>{db.cart=db.cart.filter(x=>x!==row);save();drawCart()}));wrapper.append(line);
 const below=node('div','row center between');const q=document.createElement('input');q.className='qty';q.type='number';q.step='0.1';q.min='0.1';q.max='999';q.value=row.quantity;q.onchange=()=>{const val=Number(q.value);if(val>0&&val<=999){row.quantity=val;save();drawCart()}};below.append(q);below.append(node('div','sum',fmt(p.price*row.quantity,p.currency)));wrapper.append(below);box.append(wrapper)}
 let summary=$('cartSummary');summary.replaceChildren();summary.append(node('div','',`${rest} товаров осталось купить`));for(const c of ['PMR','MDL'])if(totals[c])summary.append(node('div','sum',fmt(totals[c],c)));if(totals.MDL && db.rate>0)summary.append(node('div','muted',`≈ ${fmt(totals.PMR+totals.MDL*db.rate,'PMR')} по заданному курсу`));if(!db.cart.length)summary.append(node('div','muted','Список пуст. Добавляй товары из каталога.'))}
function matchCandidates(base){return db.products.filter(p=>p.store!==base.store).map(p=>{const key=C.pairKey(base.id,p.id),decision=db.matches[key],sim=C.similarity(base,p);return {p,decision,sim}}).filter(x=>x.decision!=='different'&&(x.decision==='same'||x.sim.score>=.22)).sort((a,b)=>(b.decision==='same')-(a.decision==='same')||b.sim.score-a.sim.score)}
function showCompare(id){state.compareId=id;$('compareDialog').showModal();drawCompare()}
function choice(base,p,decision){db.matches[C.pairKey(base.id,p.id)]=decision;save();drawCompare();notify(decision==='same'?'Совпадение подтверждено':'Совпадение отклонено')}
function drawCompare(){const base=db.products.find(p=>p.id===state.compareId);if(!base)return;const body=$('compareBody');body.replaceChildren();$('compareName').textContent=base.name;
 const candidates=matchCandidates(base);let confirmed=[base,...candidates.filter(x=>x.decision==='same'||x.sim.sure).map(x=>x.p)];confirmed=confirmed.filter((p,i,arr)=>arr.findIndex(q=>q.id===p.id)===i);
 body.append(node('p','muted tiny','Подтверждённые совпадения и надёжные автоматические пары. Для расчёта выгоды необходим одинаковый товар, известная фасовка и курс валют.'));
 const items=[];for(const shop of ['Шериф','Linella','Local']){const matches=confirmed.filter(p=>p.store===shop);let p=matches[0];if(matches.length>1){p=matches.slice().sort((a,b)=>{const aa=C.amount(a),bb=C.amount(b);return (aa?aa.unitPrice:Infinity)-(bb?bb.unitPrice:Infinity)})[0]}
 const panel=node('div','compare-shop');panel.append(node('div','section-tag',shop));if(p){panel.append(node('div','',p.name));panel.append(node('div','sum',fmt(p.price,p.currency)));let by=C.amount(p);if(by)panel.append(node('div','muted','≈ '+fmt(by.unitPrice,p.currency)+'/'+(by.kind==='kg'?'кг':'л')));if(p.price_origin==='receipt')panel.append(node('div','historical','⚠ Цена из старого чека'));if(p.currency==='MDL'&&!(db.rate>0))panel.append(node('div','warning','Укажи курс MDL → ПМР в настройках'));if(by&&((p.currency==='PMR')||db.rate>0))items.push({panel,p,by,converted:by.unitPrice*(p.currency==='MDL'?db.rate:1)})}else panel.append(node('div','muted','Пока нет подтверждённого предложения'));body.append(panel)}
 if(items.length>=2){const anchor=items[0].by.kind;const comparable=items.filter(x=>x.by.kind===anchor);if(comparable.length>=2){const best=comparable.reduce((a,b)=>a.converted<=b.converted?a:b);best.panel.classList.add('best');best.panel.append(node('div','saved','★ Лучшая приведённая цена из сравнимых предложений'))}}
 body.append(node('h3','','Возможные совпадения'));const suggestions=candidates.filter(x=>x.decision!=='same'&&!x.sim.sure).slice(0,12);if(!suggestions.length)body.append(node('div','muted','Похожие позиции пока не найдены. Можно связать товары вручную ниже.'));
 for(const x of suggestions){const box=node('div','compare-suggestion');box.append(node('div','',`${x.p.name} · ${x.p.store}`));box.append(node('div','muted tiny',fmt(x.p.price,x.p.currency)));box.append(btn('✓ Один товар','mini',()=>choice(base,x.p,'same')));box.append(btn('✕ Не совпадает','mini',()=>choice(base,x.p,'different')));body.append(box)}
 const search=node('input');search.placeholder='Ручной поиск в других магазинах...';search.setAttribute('aria-label','Найти товар для связи');body.append(search);const results=node('div');body.append(results);search.oninput=()=>{results.replaceChildren();let n=C.norm(search.value);if(n.length<3)return;for(const p of db.products.filter(x=>x.store!==base.store&&C.norm(x.name).includes(n)).slice(0,8)){
 const r=node('div','compare-suggestion');r.append(node('div','',p.store+' · '+p.name));r.append(btn('Связать вручную','mini',()=>choice(base,p,'same')));results.append(r)}}}
function drawStats(){const totals={};for(const p of db.products)totals[p.store]=(totals[p.store]||0)+1;
 $('stats').replaceChildren();for(const [shop,num] of Object.entries(totals))$('stats').append(node('div','',`${shop}: ${num} товаров`));$('stats').append(node('div','muted','Чеки «Шерифа»: '+db.receipts.length+', строк: '+db.receipts.reduce((a,r)=>a+r.items.length,0)));$('stats').append(node('div','muted','Последняя загрузка: '+dateLabel(db.lastSync)));if(db.rate)$('rateInput').value=db.rate;
 $('syncInfo').textContent=db.lastSync?'Последнее обновление: '+dateLabel(db.lastSync):'Импорт ещё не выполнялся'}
let networkId=0;const pending=new Map();window.madaraNetworkReply=(id,response)=>{if(id===-1){notify(response);return}const callbacks=pending.get(id);if(!callbacks)return;pending.delete(id);if(response.startsWith('ERROR: '))callbacks.reject(Error(response.slice(7)));else callbacks.resolve(response)};
function fetchCroco(url){return new Promise((resolve,reject)=>{if(!native){reject(Error('Импорт через Croco доступен в Android-приложении, не в обычном HTML-файле.'));return}const id=++networkId;pending.set(id,{resolve,reject});native.fetchPage(url,id);setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(Error('Превышено время ожидания ответа'))}},45000)})}
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function sync(){if(state.syncBusy)return;state.syncBusy=true;state.syncAbort=false;$('syncStart').disabled=true;$('syncStop').classList.remove('hidden');const ids=$('syncDepth').value==='all'?Object.keys(C.categoryLabels).map(Number):[1,2,3,4,5,6,7,9];const totalPages=Number($('syncPages').value);const stores=[['linella','Linella'],['local-discounter','Local']];const max=stores.length*ids.length*totalPages;let tried=0,parsed=0,fail=[];
 try{for(const [slug,store] of stores){if(state.syncAbort)break;for(const cat of ids){if(state.syncAbort)break;let previous='';for(let page=1;page<=totalPages;page++){
 if(state.syncAbort)break;
 const url=`https://croco.md/ru/produse-category/${cat}/store/${slug}${page>1?'?page='+page:''}`;
 $('syncInfo').textContent=`${store} · ${C.categoryLabels[cat]} · стр. ${page} из ${totalPages}\nОбработано ${tried}/${max}, товаров: ${parsed}`;
 try{const html=await fetchCroco(url);const doc=new DOMParser().parseFromString(html,'text/html');const data=C.extractOffers(doc,store,cat);
 if(!data.length){if(page===1)fail.push(`${store} / ${cat}: пустой результат`);break}
 const signature=data.map(p=>C.norm(p.name)+p.price).join('|');if(signature===previous)break;previous=signature;
 for(const p of data){const key=C.norm(p.name);let exists=db.products.find(x=>x.store===store&&C.norm(x.name)===key);
 if(exists){Object.assign(exists,{name:p.name,price:p.price,old_price:p.old_price,discount_pct:p.discount_pct,last_seen:p.last_seen,expiry_text:p.expiry_text,source_url:p.source_url,category:p.category,image_url:exists.image_data?exists.image_url:p.image_url||exists.image_url})}else db.products.push({...p,id:db.nextId++,auto_category:p.category,user_category:'',image_data:''});parsed++}
 save();if(data.length<24)break;
 }catch(e){fail.push(store+' '+cat+' стр.'+page+': '+e.message);break}
 finally{tried++;$('syncProgress').style.width=(100*tried/max)+'%'}
 if(!state.syncAbort)await pause(1300);
 }}}
 if(parsed>0){db.lastSync=new Date().toISOString();save()}
 $('syncInfo').textContent=`Завершено. Получено предложений: ${parsed}; проверено страниц: ${tried}.`+(fail.length?'\nОшибки: '+fail.slice(0,5).join(' / '):'')+(state.syncAbort?'\nОстановлено пользователем.':'');
 if(fail.length && !parsed)notify('Сайт не отдал товары. Данные «Шерифа» сохранены.');else notify('Каталог обновлён: '+parsed+' предложений');drawCatalog();
 }finally{state.syncBusy=false;$('syncStart').disabled=false;$('syncStop').classList.add('hidden');const message=$('syncInfo').textContent;drawStats();$('syncInfo').textContent=message}}
function migrateBackup(data){
 if(Array.isArray(data.receipt_items)){
  const items=data.receipt_items;
  for(const receipt of data.receipts||[])receipt.items=items.filter(x=>String(x.receipt_id)===String(receipt.receipt_id)).sort((a,b)=>a.line_number-b.line_number);
  data.cart=(data.shopping_items||[]).map(x=>({id:x.product_id,quantity:x.quantity,checked:!!x.checked}));
  const matches={};for(const p of data.product_matches||[])matches[C.pairKey(p.product_a,p.product_b)]=p.decision;
  data.matches=matches;
  data.rate=Number((data.settings||[]).find(x=>x.key==='mdl_to_pmr')?.value)||null;
  data.nextId=Math.max(1,...data.products.map(p=>p.id+1));
  data.lastSync=null;
 }
 data.receipts=data.receipts||[];
 for(const r of data.receipts)r.items=r.items||[];
 return data;
}
function setup(){for(const id of ['manualCategory','catFilter','categoryOverride']){for(const cat of C.cats){const op=new Option(cat,cat);$(id).add(op)}}$('manualCategory').value='Другое';
 document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>changedView(b.dataset.view));
 document.querySelectorAll('[data-store]').forEach(b=>b.onclick=()=>{state.store=b.dataset.store;state.limit=50;document.querySelectorAll('[data-store]').forEach(x=>x.classList.toggle('chosen',x===b));drawCatalog()});
 $('search').oninput=e=>{state.query=e.target.value;state.limit=50;drawCatalog()};$('catFilter').onchange=e=>{state.cat=e.target.value;state.limit=50;drawCatalog()};$('sort').onchange=e=>{state.sort=e.target.value;drawCatalog()};$('favsOnly').onchange=e=>{state.fav=e.target.checked;drawCatalog()};$('currentOnly').onchange=e=>{state.current=e.target.checked;drawCatalog()};$('more').onclick=()=>{state.limit+=50;drawCatalog()};
 $('manualForm').onsubmit=submitManual;$('cancelEdit').onclick=resetManual;
 $('deleteManual').onclick=()=>{const p=db.products.find(x=>x.id===state.editing);if(!p||p.store!=='Шериф'||p.price_origin!=='manual')return;
 if(!confirm('Удалить товар «'+p.name+'»? Данные оригинальных чеков сохранятся.'))return;
 db.products=db.products.filter(x=>x.id!==p.id);db.cart=db.cart.filter(x=>x.id!==p.id);
 for(const key of Object.keys(db.matches))if(key.split(':').map(Number).includes(p.id))delete db.matches[key];
 save();resetManual();changedView('catalog');notify('Товар удалён')};$('closeCompare').onclick=()=>$('compareDialog').close();$('closeCategory').onclick=()=>$('editCategory').close();
 $('categorySave').onclick=()=>{const p=db.products.find(x=>x.id===state.editingCategory);if(p){p.user_category=$('categoryOverride').value;save();drawCatalog()}$('editCategory').close()};
 $('rateSave').onclick=()=>{const rate=Number($('rateInput').value);if(!(rate>.001&&rate<100)){notify('Укажи положительный курс');return}db.rate=rate;save();notify('Курс сохранён')};
 $('syncStart').onclick=sync;$('syncStop').onclick=()=>{state.syncAbort=true;notify('Остановка после текущей страницы')};
 $('exportBtn').onclick=()=>{const json=JSON.stringify(db);if(native)native.exportBackup(json);else {const url=URL.createObjectURL(new Blob([json],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='madara-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),500)}};
 $('importFile').onchange=e=>{const file=e.target.files?.[0];if(!file)return;const r=new FileReader();r.onload=()=>{try{const data=migrateBackup(JSON.parse(r.result));if(!data||!Array.isArray(data.products)||!Array.isArray(data.receipts)||data.products.length>30000)throw Error('Неизвестный формат');if(!confirm('Заменить текущую базу данными из резервной копии?'))return;db=data;db.cart=db.cart||[];db.matches=db.matches||{};db.nextId=Math.max(db.nextId||0,...db.products.map(p=>p.id+1));save();changedView('catalog');notify('Копия восстановлена')}catch(error){notify('Не удалось восстановить: '+error.message)}};r.readAsText(file)};
 drawCatalog();drawReceipts();drawStats()}
window.madaraBack=()=>{if($('compareDialog').open)$('compareDialog').close();else if($('editCategory').open)$('editCategory').close();else changedView('catalog')};
setup();
