package md.madara.ceniha;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int FILE_PICK = 1001, BACKUP_WRITE = 1002;
    private static final String USER_AGENT = "MadaraCenihaPersonalCatalog/0.6";
    private final Object diskLock = new Object();
    private WebView web;
    private ValueCallback<Uri[]> chooseFiles;
    private String pendingBackup;
    private String robotsCache;
    private long robotsCacheTime;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(15, 11, 25));
        getWindow().setNavigationBarColor(Color.rgb(15, 11, 25));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(15, 11, 25));
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri url=req.getUrl();
                if ("file".equals(url.getScheme()) && "android_asset".equals(url.getHost())) return false;
                if ("https".equals(url.getScheme()) || "http".equals(url.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,url)); } catch(ActivityNotFoundException ignored) {}
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(chooseFiles != null) chooseFiles.onReceiveValue(null);
                chooseFiles=callback;
                Intent pick=new Intent(Intent.ACTION_GET_CONTENT);
                pick.setType("image/*");
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                try{startActivityForResult(Intent.createChooser(pick,"Выберите фотографию"), FILE_PICK);}
                catch(ActivityNotFoundException e){chooseFiles=null;callback.onReceiveValue(null);}
                return true;
            }
        });
        web.addJavascriptInterface(new NativeBridge(),"MadaraNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode == FILE_PICK){
            if(chooseFiles!=null){
                Uri uri=(resultCode==RESULT_OK && data!=null)?data.getData():null;
                chooseFiles.onReceiveValue(uri!=null?new Uri[]{uri}:null);
                chooseFiles=null;
            }
        }else if(requestCode == BACKUP_WRITE){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingBackup!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out!=null)out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                }catch(Exception e){ nativeReply(-1,"ERROR: Не удалось сохранить резервную копию: "+e.getMessage()); }
            }
            pendingBackup=null;
        }
    }

    @Override public void onBackPressed(){
        web.evaluateJavascript("window.madaraBack ? window.madaraBack() : null",null);
    }

    private String download(String link,int maxBytes) throws IOException {
        URL url=new URL(link);
        for(int redirect=0;redirect<3;redirect++){
            if(!"https".equalsIgnoreCase(url.getProtocol()) || !isCrocoHost(url.getHost()))
                throw new IOException("Адрес не принадлежит croco.md");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod("GET");
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent",USER_AGENT);
            c.setRequestProperty("Accept-Language","ru-RU,ru;q=0.9");
            int status=c.getResponseCode();
            if(status==301 || status==302 || status==303 || status==307 || status==308){
                String loc=c.getHeaderField("Location");
                c.disconnect();
                if(loc==null)throw new IOException("Редирект без адреса");
                url=new URL(url,loc);
                continue;
            }
            if(status==404 && "/robots.txt".equals(url.getPath())) { c.disconnect();return ""; }
            if(status!=200){c.disconnect();throw new IOException("Ошибка сайта HTTP "+status);}
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buffer=new byte[16384];int n;
                while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>maxBytes)throw new IOException("Страница слишком большая");}
                return out.toString("UTF-8");
            }finally{c.disconnect();}
        }
        throw new IOException("Слишком много перенаправлений");
    }

    private boolean isCrocoHost(String host){
        return "croco.md".equalsIgnoreCase(host) || "www.croco.md".equalsIgnoreCase(host);
    }

    private synchronized String getRobots() throws IOException {
        if(robotsCache!=null && System.currentTimeMillis()-robotsCacheTime < 30*60*1000L) return robotsCache;
        // Fail closed if robots.txt cannot be checked. No crawling around a block.
        robotsCache=download("https://croco.md/robots.txt",300000);
        robotsCacheTime=System.currentTimeMillis();
        return robotsCache;
    }

    private boolean allowedByRobots(String path) throws IOException {
        String robots=getRobots();
        if(robots.trim().isEmpty())return true; // Only when robots.txt explicitly returned HTTP 404/empty.
        boolean inApplicableGroup=false;
        boolean sawAnyRule=false;
        int longestAllow=-1,longestDisallow=-1;
        for(String raw:robots.split("\\r?\\n")){
            String line=raw.split("#",2)[0].trim();if(line.isEmpty())continue;
            int colon=line.indexOf(':');if(colon<0)continue;
            String key=line.substring(0,colon).trim().toLowerCase(Locale.ROOT);
            String value=line.substring(colon+1).trim();
            if(key.equals("user-agent")){
                if(sawAnyRule){inApplicableGroup=false;sawAnyRule=false;}
                if(value.equals("*") || value.equalsIgnoreCase(USER_AGENT))inApplicableGroup=true;
                continue;
            }
            if(!(key.equals("allow")||key.equals("disallow")))continue;
            sawAnyRule=true;
            if(!inApplicableGroup || value.isEmpty())continue;
            // Robots.txt: prefix, '*' wildcard and optional '$' end marker.
            boolean endAnchor=value.endsWith("$");
            String rule=endAnchor?value.substring(0,value.length()-1):value;
            StringBuilder expression=new StringBuilder("^");
            for(int k=0;k<rule.length();k++){
                char symbol=rule.charAt(k);
                if(symbol=='*')expression.append(".*");
                else expression.append(java.util.regex.Pattern.quote(String.valueOf(symbol)));
            }
            expression.append(endAnchor?"$":".*");
            String regex=expression.toString();
            boolean matches;
            try{matches=path.matches(regex);}catch(Exception e){throw new IOException("Неизвестное правило robots.txt");}
            if(matches){
                int length=value.length();
                if(key.equals("allow"))longestAllow=Math.max(longestAllow,length);
                else longestDisallow=Math.max(longestDisallow,length);
            }
        }
        return longestDisallow<0 || longestAllow>=longestDisallow;
    }

    private void nativeReply(int request,String payload){
        runOnUiThread(()->{
            if(web!=null)web.evaluateJavascript("window.madaraNetworkReply("+request+","+JSONObject.quote(payload)+")",null);
        });
    }

    private final class NativeBridge {
        @JavascriptInterface public String loadData(){
            synchronized(diskLock){
                File f=new File(getFilesDir(),"madara_data.json");
                if(!f.isFile())return "";
                try(FileInputStream in=new FileInputStream(f)){
                    ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[8192];int n;
                    while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>35*1024*1024)return "";}
                    return out.toString("UTF-8");
                }catch(Exception e){return "";}
            }
        }
        @JavascriptInterface public boolean saveData(String json){
            if(json==null || json.length()>25*1024*1024)return false;
            synchronized(diskLock){
                File dest=new File(getFilesDir(),"madara_data.json");
                File tmp=new File(getFilesDir(),"madara_data.tmp");
                try(FileOutputStream out=new FileOutputStream(tmp)){
                    out.write(json.getBytes(StandardCharsets.UTF_8));out.getFD().sync();
                }catch(Exception e){return false;}
                // Same directory: atomic rename on Android app private filesystem.
                return tmp.renameTo(dest) || (dest.delete() && tmp.renameTo(dest));
            }
        }
        @JavascriptInterface public void exportBackup(String json){
            if(json==null || json.length()>25*1024*1024)return;
            runOnUiThread(()->{
                pendingBackup=json;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE,"madara-backup.json");
                startActivityForResult(i,BACKUP_WRITE);
            });
        }
        @JavascriptInterface public void fetchPage(String link,int requestId){
            new Thread(()->{
                try{
                    URL u=new URL(link);
                    if(!"https".equalsIgnoreCase(u.getProtocol()) || !isCrocoHost(u.getHost()) ||
                       !u.getPath().matches("/ru/produse-category/\\d{1,2}/store/(linella|local-discounter)"))
                        throw new IOException("Недопустимый адрес категории");
                    if(!allowedByRobots(u.getFile()))throw new IOException("Доступ запрещён robots.txt");
                    nativeReply(requestId,download(link,2800000));
                }catch(Exception e){nativeReply(requestId,"ERROR: "+e.getMessage());}
            },"CrocoFetch").start();
        }
    }
}
